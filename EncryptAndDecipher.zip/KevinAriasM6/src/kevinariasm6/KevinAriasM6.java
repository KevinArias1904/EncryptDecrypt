/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kevinariasm6;

/**
 *
 * @author Admin
 */
import java.util.Scanner;
public class KevinAriasM6 {
    
    /**
     * @param args the command line arguments
     */      
    public static void main(String[] args) {         
       
         //in the this main it promps the user for an email and a password
         //then it saves the email and password in the variables in the account class
         Account account = new Account();
         Scanner scan = new Scanner(System.in);
         String encrypted;
         String deciphered;
         
         System.out.println("The email should only have 1 @ symbol and should have at least 1 dot(.) \n"
                 + "after the @ symbol. There must be at least 2 characters before the @ symbol.");
             System.out.println("");
         do{ 
             System.out.println("Enter Email: ");
             account.email = scan.nextLine();         
         }while(!account.validateEmail());
         System.out.println("Thanks Email Saved.");

    
         //this one is the password validation
         System.out.println("");
         System.out.println("Enter a password it must contain 1 capital letter, 1 lowercase letter, "
                 + "1 number, and 1 special character. " + "\n" 
                 + "The password must be at least 6 characters long.");
         do{
            System.out.println("Enter Password: ");
            account.password = scan.nextLine();         
         }while(!account.validatePassword());
         System.out.println("Thanks Password Saved.");
        
         //this calls the encrypted and deciphered methods
         //saves the strings in two new varaibles for the returned Strings to 
         //to be printed from
         //the mothods
         encrypted = account.encryptPassword();
         //the decipher method receives the encrypted password to decipher it
         deciphered = account.decipher(encrypted);
         //then prints them out
         System.out.println("\n");
         System.out.println("The encrypted Password: " + encrypted);
         System.out.println("The deciphered Password: " + deciphered);
         System.out.println("\n");
             
    }
    
}
