/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kevinariasm6;

/**
 *
 * @author Admin
 */

public class Account {

    //these are the email and password variables
    //they hold the emeail and password enterd by the user in the main
    public String email;
    public String password;
       
    
//this method validates the email
//checking it the reqirements
public boolean validateEmail(){

         //this checks how many @symbols there are and if there is more than one
        //will make you change that
        int countOfAt = 0;  
        for(int i = 0; i < email.length(); i++){
        switch(email.charAt(i)){
            case '@':
            countOfAt++;        
        }
        }
        if(countOfAt < 1 || countOfAt > 1){
         System.out.println("Email needs an @ symbol and can only have one @ symbol.");
        }
        
        //this will check if there are atleast one dot.
        //it will check and say to enter a dot
        int countOfDot = 0;  
        for(int i = 0; i < email.length(); i++){
        switch(email.charAt(i)){
            case '.':
            countOfDot++;        
        }
        }
        if(countOfDot < 1){
         System.out.println("Email needs to have alteast one Dot in the email.");
        }
    
        //this checks if there are more than 2 characters befor the @
        char at = '@';
        int countOfCharBeforAt = email.indexOf(at);
        
        if(countOfCharBeforAt <= 1){
            System.out.println("There must be atleast 2 characters befor the @.");            
        }      
        
        //this checks if there are 2 or more characters after the @
        char aT = '@';
        int countOfCharAfterAt = email.indexOf(aT);
        String subOfChar = email.substring( countOfCharAfterAt + 1, email.length());
        int numOfChar = subOfChar.length();
        
        if(numOfChar <= 1){
            System.out.println("There must be atleast 2 characters after the @.");            
        } 
        
        
        //this makes sure there are atleast on dot after the @
        char symbol = '@';
        int dotsAfter = email.indexOf(symbol);
        String SubstringOfChar = email.substring(dotsAfter + 1, email.length());
        int countOfDotAfter = 0;  
        for(int i = 0; i < SubstringOfChar.length(); i++){
        switch(SubstringOfChar.charAt(i)){
            case '.':
            countOfDotAfter++;        
        }
        }
        if(countOfDotAfter < 1){
         System.out.println("Email needs to have alteast one Dot after the @ symbol example@gmail.com");
        }
        
        
        //this checks if the email ends in with 2 or more characters after last dot.
        char com = '.';
        String subOfCom = email.substring(email.lastIndexOf(com) + 1, email.length());        
        if(subOfCom.length() < 2){
         System.out.println("Email needs to end in with 2 or more characters example@gmail.com");
        }
        
        
        return countOfAt == 1 && countOfDot >= 1 && countOfCharBeforAt >= 2 && numOfChar >= 2
               && countOfDotAfter >= 1 && subOfCom.length() >= 2; 
}

       
//this methods validates the password checking if it has the 
//spacific requirements
  public boolean validatePassword(){
     
      
        //this checks is the password is longer than 6 characters 
      if(password.length() < 6){
         System.out.println("Password must be longer.");        
      }
          
       
      //this checks is the passoword has lowercase letters
      int countOfUpper = 0;
      for(int i = 0; i < password.length(); i++){
         char character = password.charAt(i); 
         if(Character.isUpperCase(character)){
            int count = 0;
            count++;
            countOfUpper = count;
           }              
        }   
        if(countOfUpper < 1){         
        System.out.println("Password must have an upercase Letter.");        
        } 
      
         //this checks is the passoword has lowercase letters
         int countOfLower = 0;
         for(int i = 0; i < password.length(); i++){
         char character = password.charAt(i); 
         if(Character.isLowerCase(character)){         
             int count = 0; 
             count++;           
             countOfLower = count;
           }              
        }   
        if(countOfLower < 1){                            
         System.out.println("Password must have a lowercase Letter.");        
        } 
      
        //this will check is the password has a number
        int countOfNumber = 0;
        for(int i = 0; i < password.length(); i++){
         char character = password.charAt(i);
          if(Character.isDigit(character)){
             int count = 0; 
             count++;           
             countOfNumber = count;
          }        
        }
        if(countOfNumber < 1){        
            System.out.println("Password must have a Number.");  
          }  
      
         //this one will check if it has a special character 
          int countOfCharacter = 0;
          for(int i = 0; i < password.length(); i++){
          switch(password.charAt(i)){
              case '!': 
              case '@':
              case '#':
              case '$':
              case '%':
              case '^':
              case '&':
              case '*':
              case '(':
              case ')':
              case '_':
              case '-':
              case '+':
              case '=':
              case '/':
              case '<':
              case '>':
              case '|':
              case '.':
              case 'Ω':
              case 'ε':              
              case 'α':
              case 'ß':
              case 'Φ': 
             countOfCharacter++;                
          }
                 
          }
          if(countOfCharacter == 0){        
            System.out.println("Password must have a Special character it could have ascii table, such as ΩεαßΘΦ.");  
          } 
    
          
       return countOfUpper >= 1 && countOfLower >= 1 && countOfNumber >= 1 && countOfCharacter >= 1; 
    
  }



public String encryptPassword(){
    
     //this is the decryption using the string builder
     StringBuilder encryptedPassword = new StringBuilder();
              
     //this is the math operation
     for(int i = 0; i < password.length(); i++){
     char character = password.charAt(i);
     encryptedPassword.append((char) (character + 4));
     }
     //password using math operation
      System.out.println("");
      System.out.println("Encrypt Password Steps.");   
      System.out.println("Password using a math operation: " + encryptedPassword);
     
    
//   swap operation
//   this is the swap operation
     String swappedPassword = ""; 
     for(int i = encryptedPassword.length() - 1; i >= 0; i--){
     char character = encryptedPassword.charAt(i);
     swappedPassword += character;
     }
     encryptedPassword.replace(0, encryptedPassword.length(), swappedPassword);
//   encryptedPassword.reverse();
     System.out.println("Password swap operation: " + encryptedPassword);
     

     //distracter Character
     //this adds the distracter character to the string builder
     encryptedPassword.append("☺");
     System.out.println("Password with distracter character: " + encryptedPassword);
     
     //encrypted as letters
     System.out.println("");
     System.out.println("Encrypted as Letters: " + encryptedPassword);
     //encrypted as numbers
     System.out.print("Encrypted as Numbers: ");
     for(int i = 0; i < encryptedPassword.length(); i++){
         System.out.print((int) encryptedPassword.charAt(i) + " ");
         if(encryptedPassword.charAt(i) == encryptedPassword.length()){
             break;
         }
     }
     
     
     return encryptedPassword.toString();
}


public String decipher(String encryptedPassword){
     
    //this is the deceiphered password
     String decryptedPassword = "";

     //this String holds the encrypted password 
     //substrings the distracter character
     String passwordWDistracter = encryptedPassword.substring(0, encryptedPassword.length() - 1);   
     System.out.println("");
     System.out.println("");
     System.out.println("Decipher Password Steps.");
     System.out.println("Password without the distracter character: " + passwordWDistracter);
       
   
     //this reverses the math operation
     String passwordSwapped = "";
     for(int i = passwordWDistracter.length() -1; i >= 0; i--){
     char character = passwordWDistracter.charAt(i);
      passwordSwapped += character;
     }
     System.out.println("Password Swapped back: " + passwordSwapped);
     
     
     //this reverses the math operation on the password    
      for(int i = 0; i < passwordSwapped.length(); i++){
       char character = passwordSwapped.charAt(i);
       char reversedChar = (char) (character - 4);
       decryptedPassword += reversedChar;
     }
     System.out.println("Password reversed the math operation : " + decryptedPassword);

     
    return decryptedPassword;  
}


}